import java.util.HashMap;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;


public class GuiClient extends Application {

    // Scene Elements
    TextField usernameInput;
    TextField chatInput;
    Button loginButton;
    Button sendChatButton;
    Label statusLabel;
    Label gameInfoLabel;
    ListView<String> messageList;
    GridPane boardGrid;
    Button[] columnButtons;
    Button rematchButton;
    Button quitButton;
    HBox gameOverOptionsBox;

    // Scene Management Variables
    HashMap<String, Scene> sceneMap;
    Scene loginScene;
    Scene gameScene;
    Stage primaryStage;

    // Client State
    Client clientConnection;
    boolean gameActive = false;
    int myPlayerNumberInGame = 0;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage;
        sceneMap = new HashMap<>();

        // Initialize Client Connection
        clientConnection = new Client(data -> {
            Platform.runLater(() -> {
                switch (data.type) {
                    case USERNAME:
                        clientConnection.playerName = data.message;
                        statusLabel.setText("Waiting for another user!");
                        statusLabel.setTextFill(Color.BLACK);
                        break;

                    case USERNAME_ERROR:
                        statusLabel.setText("Username Error: " + data.message);
                        statusLabel.setTextFill(Color.RED);
                        loginButton.setDisable(false);
                        usernameInput.setDisable(false);
                        break;

                    case GAME_STARTED:
                        clientConnection.gameNumber = data.gameNumber;
                        myPlayerNumberInGame = data.playerNumber;
                        gameActive = true;

                        initializeBoardGrid(); // Clear and re-populate the grid
                        messageList.getItems().clear();

                        if (primaryStage.getScene() != sceneMap.get("Game")) {
                            primaryStage.setScene(sceneMap.get("Game"));
                        }
                        gameInfoLabel.setText("Game " + clientConnection.gameNumber + " | Player " + myPlayerNumberInGame + " (" + clientConnection.playerName + ")");

                        chatInput.setDisable(false);
                        sendChatButton.setDisable(false);

                        gameOverOptionsBox.setVisible(false);
                        gameOverOptionsBox.setManaged(false);
                        rematchButton.setDisable(false);
                        rematchButton.setText("Rematch");
                        quitButton.setDisable(false);
                        break;

                    case GAME_TEXT:
                        if (data.message != null && gameActive) {
                            gameInfoLabel.setText(data.message);
                        }
                        break;

                    case CONNECT_FOUR_MOVE:
                        if (gameActive && data.gameNumber == clientConnection.gameNumber) {
                            updateBoardGrid(data.column, data.row, data.playerNumber);
                        }
                        break;

                    case CHAT:
                        addMessageToList(data.playerName + ": " + data.message);
                        break;

                    case GAME_OVER:
                        if (gameActive && data.gameNumber == clientConnection.gameNumber) {
                            gameActive = false;
                            gameInfoLabel.setText("Game Over! " + data.message);
                            gameOverOptionsBox.setVisible(true);
                            gameOverOptionsBox.setManaged(true);
                            rematchButton.setDisable(false);
                            rematchButton.setText("Rematch");
                            quitButton.setDisable(false);
                        }
                        break;
                    // User text
                    case TEXT:
                        statusLabel.setText(data.message);
                        statusLabel.setTextFill(Color.BLACK);
                        break;
                }
            });
        });
        clientConnection.start();

        setLoginScreen();

        setGameScreen();
        initializeBoardGrid(); // Initialize the board grid with cells

        // Setup Stage
        primaryStage.setTitle("Connect Four");
        primaryStage.setScene(sceneMap.get("Login"));
        primaryStage.setOnCloseRequest(e -> {
            handleQuitAction();
        });
        primaryStage.show();
    }

    // Attempts to log in the user with the entered username.
    private void attemptLogin() {
        String username = usernameInput.getText().trim();
        if (username.isEmpty()) {
            statusLabel.setText("Username cannot be empty.");
            statusLabel.setTextFill(Color.RED);
            return;
        }
        if (clientConnection != null) {
            statusLabel.setTextFill(Color.BLACK);
            loginButton.setDisable(true);
            usernameInput.setDisable(true);
            clientConnection.send(new Message(username));
        } else {
            statusLabel.setText("Error: Client not connected.");
            statusLabel.setTextFill(Color.RED);
        }
    }

    // Sends a move request to the server for the specified column.
    private void attemptMove(int column) {
        if (clientConnection != null && clientConnection.gameNumber != -1) {
            clientConnection.send(new Message(clientConnection.gameNumber, myPlayerNumberInGame, column));
        } else {
            System.out.println("Cannot send move: Not connected or not in a game.");
        }
    }

    // Sends the typed chat message to the server.
    private void sendChatMessage() {
        String text = chatInput.getText().trim();
        if (!text.isEmpty() && gameActive && clientConnection != null) {
            clientConnection.send(new Message(MessageType.CHAT, clientConnection.gameNumber, clientConnection.playerName, text));
            chatInput.clear();
        }
    }

    // Handles the action when the "Rematch" button is clicked.
    private void handleRematchAction() {
        if (!gameActive && clientConnection != null && clientConnection.gameNumber != -1) {
            System.out.println("Client requesting rematch for game " + clientConnection.gameNumber);
            clientConnection.send(new Message(MessageType.REMATCH_REQUEST));

            gameInfoLabel.setText("Rematch requested... Waiting for opponent.");
            rematchButton.setDisable(true);
            rematchButton.setText("Requested");
        } else {
            System.out.println("Cannot request rematch: Game active or not connected.");
        }
    }

    // Handles the action when the "Quit" button or window close is triggered.
    private void handleQuitAction() {
        Platform.exit();
        System.exit(0);
    }


    // Adds a message to the chat list view.
    private void addMessageToList(String message) {
        if (messageList != null) {
            messageList.getItems().add(message);
            messageList.scrollTo(messageList.getItems().size() - 1);
        }
    }

    // Clears and re-initializes the board grid with empty cells using loops.
    private void initializeBoardGrid() {
        if (boardGrid != null) {
            boardGrid.getChildren().clear();
            for (int row = 0; row < 6; row++) {
                for (int col = 0; col < 7; col++) {
                    Label cell = createCellLabel();
                    boardGrid.add(cell, col, row);
                }
            }
        }
    }

    // Creates a styled Label to represent an empty cell on the board.
    private Label createCellLabel() {
        Label cell = new Label();
        cell.setPrefSize(50, 50);
        cell.setMinSize(50, 50);
        cell.setMaxSize(50, 50);
        cell.setStyle(
                "-fx-background-color: lightgrey;" +
                        "-fx-background-radius: 25;" +
                        "-fx-border-color: black;" +
                        "-fx-border-width: 1;" +
                        "-fx-border-radius: 25;"
        );
        return cell;
    }

    // Updates the color of a cell on the board grid when a piece is dropped.
    private void updateBoardGrid(int col, int row, int playerNum) {
        Node node = getNodeFromGridPane(boardGrid, col, row);
        if (node != null) {
            Label cell = (Label) node;
            String color;
            if (playerNum == 1) {
                color = "#ffff00"; // Player 1: Yellow
            } else {
                color = "#DC143C"; // Player 2: Red
            }
            cell.setStyle(
                    "-fx-background-color: " + color + ";" +
                            "-fx-background-radius: 25;" +
                            "-fx-border-color: black;" +
                            "-fx-border-width: 1;" +
                            "-fx-border-radius: 25;"
            );
        } else {
            System.err.println("Error: Could not find node at column " + col + ", row " + row + " in boardGrid.");
        }
    }

    // Helper method to retrieve a node from a specific cell in a GridPane.
    private Node getNodeFromGridPane(GridPane gridPane, int col, int row) {
        for (Node node : gridPane.getChildren()) {
            Integer nodeCol = GridPane.getColumnIndex(node);
            Integer nodeRow = GridPane.getRowIndex(node);
            int c;
            if (nodeCol == null) {
                c = 0;
            } else {
                c = nodeCol;
            }
            int r;
            if (nodeRow == null) {
                r = 0;
            } else {
                r = nodeRow;
            }
            if (c == col && r == row) {
                return node;
            }
        }
        return null;
    }
}

// Login Screen
void setLoginScreen(){
        VBox loginBox = new VBox(15);
        loginBox.setPadding(new Insets(20));
        loginBox.setAlignment(Pos.CENTER);
        loginBox.setStyle("-fx-background-color: #E0E0E0;");

        Label title = new Label("Connect Four");
        title.setFont(new Font("Arial", 20));

        usernameInput = new TextField();
        usernameInput.setPromptText("Enter Username");
        usernameInput.setMaxWidth(200);
        usernameInput.setDisable(false);

        loginButton = new Button("Submit");
        loginButton.setOnAction(e -> attemptLogin());
        loginButton.setDisable(false);

        statusLabel = new Label("Waiting for username submission.");
        statusLabel.setTextFill(Color.BLACK);

        loginBox.getChildren().addAll(title, usernameInput, loginButton, statusLabel);
        loginScene = new Scene(loginBox, 350, 250);
        sceneMap.put("Login", loginScene);
}

void setGameScreen(){
        BorderPane gamePane = new BorderPane();
        gamePane.setPadding(new Insets(10));
        gamePane.setStyle("-fx-background-color: #D3D3D3;");

        gameInfoLabel = new Label("Waiting for game...");
        gameInfoLabel.setFont(new Font("Arial", 16));
        BorderPane.setAlignment(gameInfoLabel, Pos.CENTER);
        gamePane.setTop(gameInfoLabel);

        boardGrid = new GridPane();
        boardGrid.setAlignment(Pos.CENTER);
        boardGrid.setHgap(5);
        boardGrid.setVgap(5);
        gamePane.setCenter(boardGrid);

        VBox bottomBox = new VBox(10);
        bottomBox.setPadding(new Insets(10, 0, 0, 0));
        bottomBox.setAlignment(Pos.CENTER);

        // Create Column Buttons
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        columnButtons = new Button[7];
        for (int i = 0; i < 7; i++) {
            final int col = i;
            columnButtons[i] = new Button("V");
            columnButtons[i].setMinWidth(50);
            columnButtons[i].setOnAction(e -> attemptMove(col));
            buttonBox.getChildren().add(columnButtons[i]);
        }

        messageList = new ListView<>();
        messageList.setPrefHeight(150);

        HBox chatArea = new HBox(10);
        chatArea.setAlignment(Pos.CENTER);
        chatInput = new TextField();
        chatInput.setPromptText("Type message...");
        chatInput.setPrefWidth(350);
        chatInput.setDisable(true);
        sendChatButton = new Button("Send");
        sendChatButton.setOnAction(e -> sendChatMessage());
        sendChatButton.setDisable(true);
        chatArea.getChildren().addAll(chatInput, sendChatButton);

        rematchButton = new Button("Rematch");
        rematchButton.setOnAction(e -> handleRematchAction());
        quitButton = new Button("Quit Game");
        quitButton.setOnAction(e -> handleQuitAction());

        gameOverOptionsBox = new HBox(20, rematchButton, quitButton);
        gameOverOptionsBox.setAlignment(Pos.CENTER);
        gameOverOptionsBox.setVisible(false);
        gameOverOptionsBox.setManaged(false);

        bottomBox.getChildren().addAll(buttonBox, messageList, chatArea, gameOverOptionsBox);
        gamePane.setBottom(bottomBox);

        gameScene = new Scene(gamePane, 500, 650);
        sceneMap.put("Game", gameScene);
}
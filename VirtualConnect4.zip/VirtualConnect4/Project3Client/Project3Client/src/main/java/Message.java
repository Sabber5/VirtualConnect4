import java.io.Serializable;

public class Message implements Serializable {

    static final long serialVersionUID = 42L;

    MessageType type;
    String message;
    int recipient;
    int gameNumber;
    int playerNumber;
    String playerName;
    int column;
    int row;

    public Message() {
        this.type = null; this.message = null; this.recipient = -1; this.gameNumber = -1;
        this.playerNumber = -1; this.playerName = null; this.column = -1; this.row = -1;
    }

    public Message(MessageType type) {
        this();
        if (type == MessageType.REMATCH_REQUEST ) {
            this.type = type;
        } else {
            this.type = type;
        }
    }

    public Message(int clientId) {
        this();
        this.type = MessageType.NEWUSER;
        this.recipient = clientId;
        this.message = "User " + clientId + " has joined!";
    }

    public Message(String username) {
        this();
        this.type = MessageType.CUSERNAME;
        this.playerName = username;
        this.message = username;
    }

    public Message(MessageType type, String msgContent) {
        this();
        if (type != MessageType.USERNAME_ERROR && type != MessageType.TEXT && type != MessageType.REMATCH_DECLINED) {
        }
        this.type = type;
        this.message = msgContent;
        this.recipient = -1;
    }

    public Message(MessageType type, String username, int clientId) {
        this();
        if (type != MessageType.USERNAME) {
            throw new IllegalArgumentException("Incorrect MessageType for this constructor. Use USERNAME.");
        }
        this.type = type;
        this.message = username;
        this.recipient = clientId;
    }


    public Message(boolean gameStartMarker, int gNumber, int pNumberAssigned) {
        this();
        this.type = MessageType.GAME_STARTED;
        this.gameNumber = gNumber;
        this.playerNumber = pNumberAssigned;
        this.message = "Game " + gNumber + " started. You are Player " + pNumberAssigned;
    }

    public Message(MessageType type, String gameStatusMessage, int gNumber, String relatedPlayerName) {
        this();
        if (type != MessageType.GAME_TEXT && type != MessageType.GAME_OVER) {
            throw new IllegalArgumentException("Incorrect MessageType for this constructor. Use GAME_TEXT or GAME_OVER.");
        }
        this.type = type;
        this.gameNumber = gNumber;
        this.playerName = relatedPlayerName;
        this.message = gameStatusMessage;
    }

    public Message(int gameNumber, int playerNumberInGame, int column) {
        this();
        this.type = MessageType.CONNECT_FOUR_MOVE;
        this.gameNumber = gameNumber;
        this.playerNumber = playerNumberInGame;
        this.column = column;
        this.row = -1;
    }

    public Message(int gameNumber, int playerNumberInGame, int column, int row) {
        this();
        this.type = MessageType.CONNECT_FOUR_MOVE;
        this.gameNumber = gameNumber;
        this.playerNumber = playerNumberInGame;
        this.column = column;
        this.row = row;
    }

    public Message(MessageType type, int gameNumber, String senderName, String chatMessage) {
        this();
        if (type != MessageType.CHAT) {
            throw new IllegalArgumentException("Incorrect MessageType for chat constructor. Use CHAT.");
        }
        this.type = MessageType.CHAT;
        this.gameNumber = gameNumber;
        this.playerName = senderName;
        this.message = chatMessage;
    }

    public Message(int recipientCode, String textMessage) {
        this();
        this.type = MessageType.TEXT;
        this.recipient = recipientCode;
        this.message = textMessage;
    }
}

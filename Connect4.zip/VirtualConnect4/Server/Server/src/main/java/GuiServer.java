import java.util.function.Consumer;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class GuiServer extends Application {

    Server serverConnection;
    ListView<String> listUsers;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Connect Four Server - Connected Users");

        // Initialize UI components
        listUsers = new ListView<>();
        listUsers.setPrefWidth(250);

        Label usersLabel = new Label("Connected Users (ID: Name):");

        VBox usersBox = new VBox(5, usersLabel, listUsers);
        usersBox.setPadding(new Insets(10));

        BorderPane pane = new BorderPane();
        pane.setPadding(new Insets(10));
        pane.setStyle("-fx-background-color: #EAEAEA;");
        pane.setCenter(usersBox);

        // Initialize the server backend and set up the callback for GUI updates
        serverConnection = new Server(data -> {
            Platform.runLater(() -> {
                int count = data.recipient; // Get client ID from the message

                // Handle Username Confirmation
                if (data.type == MessageType.USERNAME) {
                    String name = data.message; // Get name from USERNAME message payload
                    String userEntry = "ID: " + count + " (" + name + ")";
                    listUsers.getItems().add(userEntry);
                }


                // Auto-scroll the user list to the bottom if items are added
                if (!listUsers.getItems().isEmpty()) {
                    listUsers.scrollTo(listUsers.getItems().size() - 1);
                }
            });
        });

        // Handle the window close request to properly shut down the application
        primaryStage.setOnCloseRequest(t -> {
            System.out.println("Server GUI closing...");
            Platform.exit();
            System.exit(0);
        });

        // Set the scene and display the primary stage
        Scene scene = new Scene(pane, 300, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.Arrays;

public class Server {

    int count = 1;
    int gameCount = 0;
    final ArrayList<ClientThread> clients = new ArrayList<>();
    final ArrayList<Game> games = new ArrayList<>();
    final ArrayList<ClientThread> clientsWaitingForGame = new ArrayList<>();
    final ArrayList<String> clientUsernames = new ArrayList<>();

    TheServer server;
    private final Consumer<Message> callback;

    Server(Consumer<Message> call) {
        this.callback = call;
        server = new TheServer();
        server.start();
    }

    // Listens for incoming client connections.
    public class TheServer extends Thread {
        @Override
        public void run() {
            try (ServerSocket mysocket = new ServerSocket(5555)) {
                System.out.println("Server is waiting for a client on port 5555!");
                while (true) {
                    try {
                        Socket connection = mysocket.accept();
                        ClientThread c = new ClientThread(connection, count);
                        synchronized(clients) {
                            clients.add(c);
                        }
                        System.out.println("Client " + count + " connected.");
                        callback.accept(new Message(count)); // Notify GUI (NEWUSER)
                        c.start();
                        count++;
                    } catch (Exception e) {
                        System.err.println("Error accepting/starting client thread: " + e.getMessage());
                    }
                }
            } catch (Exception e) {
                System.err.println("Server critical error: " + e.getMessage());
                // Use TEXT type for general server messages to GUI
                callback.accept(new Message(MessageType.TEXT, "Server launch failed: " + e.getMessage()));
            }
        }
    }

    // Handles communication with a single client.
    class ClientThread extends Thread {
        Socket connection;
        int count;
        String playerName = "";
        ObjectInputStream in;
        ObjectOutputStream out;
        Game currentGame = null;
        int playerNumberInGame = 0;

        ClientThread(Socket s, int clientCount) {
            this.connection = s;
            this.count = clientCount;
        }

        public void sendMessage(Message message) {
            if (connection == null || connection.isClosed() || out == null) {
                return;
            }
            try {
                out.writeObject(message);
                out.flush();
            } catch (Exception e) {
                System.err.println("Error sending message to client " + count + ": " + e.getMessage());
            }
        }

        @Override
        public void run() {
            try {
                out = new ObjectOutputStream(connection.getOutputStream());
                in = new ObjectInputStream(connection.getInputStream());
                connection.setTcpNoDelay(true);
                while (true) {
                    Message data = (Message) in.readObject();

                    // Update Server GUI on username attempt
                    if (data.type == MessageType.CUSERNAME) {
                        callback.accept(new Message(MessageType.TEXT,"Client " + count + " attempting username: " + data.message));
                    }

                    switch (data.type) {
                        case CUSERNAME:
                            handleUsernameRequest(data.playerName);
                            break;
                        case CONNECT_FOUR_MOVE:
                            handleMoveRequest(data.gameNumber, data.column);
                            break;
                        case CHAT:
                            handleChatRequest(data.gameNumber, data.message);
                            break;
                        case REMATCH_REQUEST:
                            handleRematchRequest(this);
                            break;
                        default:
                            System.out.println("Client " + count + " sent unhandled message type: " + data.type);
                            break;
                    }
                }
            } catch (java.io.EOFException | java.net.SocketException e) {
                System.out.println("Client " + count + " ("+playerName+") disconnected.");
            } catch (Exception e) {
                System.err.println("Error or connection closed for client " + count + " ("+playerName+"). Reason: " + e.getMessage());
            } finally {
                System.out.println("Cleaning up connection for client " + count + " ("+playerName+").");
                synchronized (clientsWaitingForGame) { clientsWaitingForGame.remove(this); }
                synchronized (clients) { clients.remove(this); }
                synchronized (clientUsernames) {
                    if (this.playerName != null && !this.playerName.isEmpty()) {
                        clientUsernames.remove(this.playerName);
                    }
                }
                if (currentGame != null && !currentGame.isGameOver) {
                    ClientThread opponent = (this == currentGame.player1) ? currentGame.player2 : currentGame.player1;
                    if (opponent != null && opponent.connection != null && !opponent.connection.isClosed()) {
                        opponent.sendMessage(new Message(MessageType.GAME_OVER, "Opponent (" + this.playerName + ") disconnected. You win!", currentGame.gameNumber, "Server"));
                        opponent.sendMessage(new Message(MessageType.TEXT, "Opponent (" + this.playerName + ") disconnected."));
                        // Put opponent back in queue
                        synchronized(clientsWaitingForGame) {
                            if (!clientsWaitingForGame.contains(opponent)) {
                                opponent.currentGame = null;
                                opponent.playerNumberInGame = 0;
                                clientsWaitingForGame.add(opponent);
                                System.out.println("Added opponent " + opponent.playerName + " back to waiting queue.");
                                startGameIfPossible(); // Check immediately if they can start new game
                            }
                        }
                    }
                    currentGame.isGameOver = true;
                    synchronized(games){ games.remove(currentGame); } // Remove game on disconnect
                }
                try {
                    if (in != null) in.close();
                    if (out != null) out.close();
                    if (connection != null) connection.close();
                } catch (IOException ioEx) {}
                callback.accept(new Message(MessageType.TEXT, "Client " + count + " ("+playerName+") disconnected."));
            }
        }


        // Handles CUSERNAME message.
        public void handleUsernameRequest(String requestedName) {
            boolean nameIsValidAndUnique = false;
            String trimmedName = ""; // Initialize

            if (requestedName != null && !requestedName.trim().isEmpty()) {
                trimmedName = requestedName.trim();
                boolean alreadyExists = false;
                synchronized(clientUsernames) {
                    for (String name : clientUsernames) {
                        if (name.equalsIgnoreCase(trimmedName)) {
                            alreadyExists = true;
                            break;
                        }
                    }
                    if (!alreadyExists) {
                        clientUsernames.add(trimmedName);
                        nameIsValidAndUnique = true;
                    }
                }
            }

            if (nameIsValidAndUnique) {
                this.playerName = trimmedName;
                sendMessage(new Message(MessageType.USERNAME, this.playerName)); // Confirm to client
                callback.accept(new Message(MessageType.USERNAME, this.playerName, this.count)); // Notify server GUI
                System.out.println("Client " + count + " set username to: '" + this.playerName + "'");

                synchronized(clientsWaitingForGame) {
                    if (!clientsWaitingForGame.contains(this) && this.currentGame == null) {
                        clientsWaitingForGame.add(this);
                        System.out.println("Client " + this.count + " (" + this.playerName + ") added to waiting queue.");
                        sendMessage(new Message(MessageType.TEXT, "Username accepted. Waiting for another player..."));
                    }
                }
                startGameIfPossible();
            } else {
                String errorMsg = (requestedName == null || requestedName.trim().isEmpty()) ?
                        "Username cannot be empty." :
                        "'" + trimmedName + "' is taken or invalid.";
                sendMessage(new Message(MessageType.USERNAME_ERROR, errorMsg));
            }
        }

        // Handles CONNECT_FOUR_MOVE message.
        private void handleMoveRequest(int msgGameNum, int column) {
            if (this.currentGame == null || this.currentGame.isGameOver) {
                sendMessage(new Message(MessageType.TEXT, "Cannot make move: Not in an active game.", -1, "Server"));
                return;
            }
            if (this.currentGame.gameNumber != msgGameNum) {
                sendMessage(new Message(MessageType.TEXT, "Error: Move sent for incorrect game.", this.currentGame.gameNumber, "Server"));
                return;
            }
            this.currentGame.processMove(this.playerNumberInGame, column);
        }

        // Handles CHAT message.
        private void handleChatRequest(int msgGameNum, String chatMsg) {
            if (this.currentGame == null) {
                sendMessage(new Message(MessageType.TEXT, "Cannot chat: Not in a game.", -1, "Server"));
                return;
            }
            if (this.currentGame.gameNumber != msgGameNum) {
                sendMessage(new Message(MessageType.TEXT, "Error: Chat sent for incorrect game.", this.currentGame.gameNumber, "Server"));
                return;
            }
            if (chatMsg == null || chatMsg.trim().isEmpty()) return; // Ignore empty chat

            ClientThread opponent = (this == currentGame.player1) ? currentGame.player2 : currentGame.player1;

            if (opponent != null && opponent.connection != null && !opponent.connection.isClosed()) {
                opponent.sendMessage(new Message(MessageType.CHAT, this.currentGame.gameNumber, this.playerName, chatMsg.trim()));
            } else {
                sendMessage(new Message(MessageType.TEXT, "Opponent is not available to receive chat.", currentGame.gameNumber, "Server"));
            }
        }

    } // End ClientThread

    // Checks waiting queue and starts game.
    private synchronized void startGameIfPossible() { 
        ClientThread player1 = null;
        ClientThread player2 = null;

        synchronized(clientsWaitingForGame) {
            if (clientsWaitingForGame.size() >= 2) {
                player1 = clientsWaitingForGame.remove(0);
                player2 = clientsWaitingForGame.remove(0);
            }
        }

        if (player1 != null && player2 != null) {
            gameCount++;
            Game newGame = new Game(gameCount, player1, player2);
            synchronized(games) {
                games.add(newGame);
            }

            player1.currentGame = newGame; player1.playerNumberInGame = 1;
            player2.currentGame = newGame; player2.playerNumberInGame = 2;

            System.out.println("Game " + gameCount + " started: " + player1.playerName + " vs " + player2.playerName);
            callback.accept(new Message(MessageType.TEXT, "Game " + gameCount + " started: " + player1.playerName + " vs " + player2.playerName));

            player1.sendMessage(new Message(true, gameCount, 1));
            player2.sendMessage(new Message(true, gameCount, 2));

            newGame.sendGameMessage(new Message(MessageType.GAME_TEXT, "Player 1 ("+player1.playerName+")'s turn.", gameCount, "Server"));
        }
    }

    // Handles REMATCH_REQUEST.
    private void handleRematchRequest(ClientThread requester) {
        if (requester.currentGame == null || !requester.currentGame.isGameOver) {
            requester.sendMessage(new Message(MessageType.TEXT, "Cannot request rematch now.", -1, "Server"));
            return;
        }

        Game lastGame = requester.currentGame;
        ClientThread opponent = null;

        synchronized (lastGame) {
            if (lastGame.player1 == requester) {
                if (lastGame.player1WantsRematch) return;
                lastGame.player1WantsRematch = true;
                opponent = lastGame.player2;
            } else if (lastGame.player2 == requester) {
                if (lastGame.player2WantsRematch) return;
                lastGame.player2WantsRematch = true;
                opponent = lastGame.player1;
            }

            // Check opponent status
            if (opponent == null || opponent.connection == null || opponent.connection.isClosed()) {
                requester.sendMessage(new Message(MessageType.TEXT, "Opponent unavailable for rematch.", lastGame.gameNumber, "Server"));
                // Reset own flag as rematch is impossible
                if (lastGame.player1 == requester) lastGame.player1WantsRematch = false;
                else lastGame.player2WantsRematch = false;
                return;
            }

            if (lastGame.player1WantsRematch && lastGame.player2WantsRematch) {
                System.out.println("Both players agreed to rematch for game " + lastGame.gameNumber + ". Resetting.");
                lastGame.sendGameMessage(new Message(MessageType.GAME_TEXT, "Both players agreed! Starting rematch...", lastGame.gameNumber, "Server"));
                lastGame.resetGame(); // Initiate the rematch
            } else {
                System.out.println(requester.playerName + " wants a rematch. Waiting for " + opponent.playerName);
                opponent.sendMessage(new Message(MessageType.GAME_TEXT, requester.playerName + " wants a rematch! Click 'Rematch' to accept.", lastGame.gameNumber, "Server"));
                requester.sendMessage(new Message(MessageType.GAME_TEXT, "Rematch requested. Waiting for " + opponent.playerName + "...", lastGame.gameNumber, "Server"));
            }
        } // End synchronized block
    }


    class Game {
        final int gameNumber;
        final ClientThread player1;
        final ClientThread player2;
        int[][] board;
        int currentPlayer;
        volatile boolean isGameOver; 
        volatile boolean player1WantsRematch; 
        volatile boolean player2WantsRematch; 

        Game(int gameNum, ClientThread p1, ClientThread p2) {
            this.gameNumber = gameNum;
            this.player1 = p1;
            this.player2 = p2;
            this.board = new int[6][7];
            this.currentPlayer = 1;
            this.isGameOver = false;
            this.player1WantsRematch = false;
            this.player2WantsRematch = false;
        }

        // Made synchronized to prevent concurrent modification issues
        public synchronized void sendGameMessage(Message message) {
            message.gameNumber = this.gameNumber; // Ensure correct game number
            if (player1 != null && player1.connection != null && !player1.connection.isClosed()) {
                player1.sendMessage(message);
            }
            if (player2 != null && player2.connection != null && !player2.connection.isClosed()) {
                player2.sendMessage(message);
            }
        }

        // Made synchronized to ensure thread safety during move processing
        public synchronized void processMove(int playerNumInGame, int column) {
            ClientThread currentThread = (playerNumInGame == 1) ? player1 : player2;

            if (isGameOver) {
                currentThread.sendMessage(new Message(MessageType.GAME_TEXT, "The game is already over.", gameNumber, "Server"));
                return;
            }
            if (playerNumInGame != currentPlayer) {
                currentThread.sendMessage(new Message(MessageType.GAME_TEXT, "It's not your turn!", gameNumber, "Server"));
                return;
            }
            if (column < 0 || column >= 7 || board[0][column] != 0) {
                currentThread.sendMessage(new Message(MessageType.GAME_TEXT, "Invalid move (column full or out of bounds).", gameNumber, "Server"));
                return;
            }

            int row = -1;
            for (int r = 5; r >= 0; r--) {
                if (board[r][column] == 0) {
                    row = r;
                    break;
                }
            }
            // This check should be redundant because of the board[0][column] check, but keep for safety
            if (row == -1) {
                currentThread.sendMessage(new Message(MessageType.GAME_TEXT, "Invalid move (column appears full).", gameNumber, "Server"));
                return;
            }
            board[row][column] = playerNumInGame;

            // Send move to BOTH players
            sendGameMessage(new Message(gameNumber, playerNumInGame, column, row));

            if (checkWin(playerNumInGame)) {
                String winnerName = (playerNumInGame == 1) ? player1.playerName : player2.playerName;
                endGame("Player " + playerNumInGame + " (" + winnerName + ") Wins!");
                return;
            }
            if (checkDraw()) {
                endGame("Game Draw!");
                return;
            }

            currentPlayer = (currentPlayer == 1) ? 2 : 1;
            String nextPlayerName = (currentPlayer == 1) ? player1.playerName : player2.playerName;
            sendGameMessage(new Message(MessageType.GAME_TEXT, "Player " + currentPlayer + " ("+nextPlayerName+")'s turn.", gameNumber, "Server"));
        }

        private boolean checkWin(int pNum) {
            final int ROW_COUNT = 6;
            final int COL_COUNT = 7;

            // Check horizontal -
            for (int row = 0; row < ROW_COUNT; row++) {
                for (int col = 0; col <= COL_COUNT - 4; col++) {
                    if (b(row, col, pNum) && b(row, col + 1, pNum) && b(row, col + 2, pNum) && b(row, col + 3, pNum)) return true;
                }
            }
            // Check vertical |
            for (int row = 0; row <= ROW_COUNT - 4; row++) {
                for (int col = 0; col < COL_COUNT; col++) {
                    if (b(row, col, pNum) && b(row + 1, col, pNum) && b(row + 2, col, pNum) && b(row + 3, col, pNum)) return true;
                }
            }
            // Check diagonal /
            for (int row = 3; row < ROW_COUNT; row++) {
                for (int col = 0; col <= COL_COUNT - 4; col++) {
                    if (b(row, col, pNum) && b(row - 1, col + 1, pNum) && b(row - 2, col + 2, pNum) && b(row - 3, col + 3, pNum)) return true;
                }
            }
            // Check diagonal \
            for (int row = 0; row <= ROW_COUNT - 4; row++) {
                for (int col = 0; col <= COL_COUNT - 4; col++) {
                    if (b(row, col, pNum) && b(row + 1, col + 1, pNum) && b(row + 2, col + 2, pNum) && b(row + 3, col + 3, pNum)) return true;
                }
            }
            return false;
        }
        private boolean b(int r, int c, int p) { return board[r][c] == p; }

        private boolean checkDraw() {
            for (int col = 0; col < 7; col++) {
                if (board[0][col] == 0) return false; // Found empty slot in top row
            }
            return true; // Top row is full
        }

        // Made synchronized to prevent issues with isGameOver flag
        private synchronized void endGame(String resultMessage) {
            if (isGameOver) return; // Already ended

            isGameOver = true;
            System.out.println("Game " + gameNumber + " ended. Result: " + resultMessage);

            // Reset rematch flags immediately when game ends
            this.player1WantsRematch = false;
            this.player2WantsRematch = false;

            String opponentNamePlayer1 = (player2 != null) ? player2.playerName : "Opponent";
            String opponentNamePlayer2 = (player1 != null) ? player1.playerName : "Opponent";

            // Send GAME_OVER to both players
            if (player1 != null) player1.sendMessage(new Message(MessageType.GAME_OVER, resultMessage, gameNumber, opponentNamePlayer1));
            if (player2 != null) player2.sendMessage(new Message(MessageType.GAME_OVER, resultMessage, gameNumber, opponentNamePlayer2));

            // Notify server GUI
            callback.accept(new Message(MessageType.GAME_OVER, "Game " + gameNumber + ": " + resultMessage, gameNumber, "Server"));

            // Remove game from active list
            synchronized (games) {
                games.remove(this);
            }
        }

        // Made synchronized for thread safety during reset
        public synchronized void resetGame() {
            // Add safety checks
            if (!isGameOver) {
                System.err.println("Warning: resetGame called on active game " + gameNumber);
                return;
            }
            if (player1 == null || player1.connection == null || player1.connection.isClosed() ||
                    player2 == null || player2.connection == null || player2.connection.isClosed()) {
                System.err.println("Error: Cannot reset game " + gameNumber + ", player disconnected.");
                // Inform remaining player if possible
                ClientThread remaining = (player1 != null && !player1.connection.isClosed()) ? player1 : player2;
                if (remaining != null) remaining.sendMessage(new Message(MessageType.TEXT, "Cannot start rematch, opponent disconnected.", gameNumber, "Server"));
                // Ensure flags are false and game is removed
                this.player1WantsRematch = false;
                this.player2WantsRematch = false;
                synchronized(games){ games.remove(this); }
                return;
            }


            System.out.println("Resetting game " + gameNumber + " for rematch.");
            for (int[] row : board) {
                Arrays.fill(row, 0);
            }
            isGameOver = false;
            currentPlayer = 1; // Player 1 starts rematch

            // Reset rematch flags after successful reset checks
            this.player1WantsRematch = false;
            this.player2WantsRematch = false;

            // Add game back to active list
            synchronized (games) {
                if (!games.contains(this)) { // Avoid duplicates if endGame didn't remove it
                    games.add(this);
                }
            }

            // Notify server GUI
            callback.accept(new Message(MessageType.TEXT, "Rematch Game " + gameNumber + " started: " + player1.playerName + " vs " + player2.playerName));

            // Send GAME_STARTED to players to reset their GUIs
            player1.sendMessage(new Message(true, gameNumber, player1.playerNumberInGame));
            player2.sendMessage(new Message(true, gameNumber, player2.playerNumberInGame));

            // Send initial turn message
            String nextPlayerName = player1.playerName;
            sendGameMessage(new Message(MessageType.GAME_TEXT, "Player 1 ("+nextPlayerName+")'s turn.", gameNumber, "Server"));
        }

    } // End Game

} // End Server

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.function.Consumer;

public class Client extends Thread {

    int gameNumber = -1;
    String playerName = "";

    Socket socketClient;
    ObjectOutputStream out;
    ObjectInputStream in;
    String serverAddress = "127.0.0.1";
    int serverPort = 5555;
    volatile boolean running = true;

    private Consumer<Message> callback;

    Client(Consumer<Message> call) {
        this.callback = call;
    }

    @Override
    public void run() {
        try {
            socketClient = new Socket(serverAddress, serverPort);
            out = new ObjectOutputStream(socketClient.getOutputStream());
            in = new ObjectInputStream(socketClient.getInputStream());
            socketClient.setTcpNoDelay(true);
            System.out.println("Client connected to server.");

            while (running) {
                try {
                    Message message = (Message) in.readObject();
                    callback.accept(message);

                } catch (Exception e) {
                    System.err.println("Error from server: " + e.getMessage());
                }
            }

        } catch (Exception e) {
            System.err.println("Error from server: " + e.getMessage());
        }
    }

    public void send(Message data) {
        try {
            out.writeObject(data);
            out.flush();
        } catch (IOException e) {
            System.err.println("Error sending message: " + e.getMessage());
        }
    }
}
